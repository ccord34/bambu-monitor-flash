﻿Bambu Monitor ESP32-S3 DualEye firmware package
Version: 20260629-030534
Target: Waveshare ESP32-S3-DualEye-LCD-1.28

Flash with PowerShell:
  .\flash.ps1 -Port COM13

Flash with cmd:
  flash.bat COM13

Required tool:
  python -m pip install esptool

Flash offsets:
  0x0000  bootloader.bin
  0x8000  partitions.bin
  0xe000  boot_app0.bin
  0x10000 firmware.bin

Online flashing:
  The same merged firmware is available as bambu_monitor_full.bin and can be used by the flash/index.html page at offset 0x0.

This package does not include source code, account token, printer data dump, local config, or SD card media files.
