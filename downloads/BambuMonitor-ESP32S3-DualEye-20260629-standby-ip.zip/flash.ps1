﻿param(
  [string]$Port = "COM13",
  [int]$Baud = 460800
)

$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

python -m esptool --chip esp32s3 --port $Port --baud $Baud write_flash -z `
  0x0000 (Join-Path $Here "bootloader.bin") `
  0x8000 (Join-Path $Here "partitions.bin") `
  0xe000 (Join-Path $Here "boot_app0.bin") `
  0x10000 (Join-Path $Here "firmware.bin")
