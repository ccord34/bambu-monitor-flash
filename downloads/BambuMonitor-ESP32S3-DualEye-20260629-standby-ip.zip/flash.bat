@echo off
set PORT=%1
if "%PORT%"=="" set PORT=COM13
python -m esptool --chip esp32s3 --port %PORT% --baud 460800 write_flash -z 0x0000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin
pause
